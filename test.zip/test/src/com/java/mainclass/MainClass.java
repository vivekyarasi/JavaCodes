package com.java.mainclass;

public class MainClass {
	
	
	public int methodForException(String s)
	{
		if(s==null||s.trim().length()==0)
		{
			throw new IllegalArgumentException("check string for not null");
		}
		return Integer.valueOf(s);
	}
	public boolean checkString(String s) {
		if(s.length()%2==0) {
			return true;
			
		}else {
			return false;
		}
		
	}
	public int addMeth(int x,int y)
	{
		return x+y;
	}
	
	public String intgreater(int a,int b)
	{
		String message=null;
		if(a>b)
		{
			message="Greater";
			
		}
		else
		{
			message="smaller.";
		}
		return message;
	}
	
	
	
	
	
	public static void main(String[] args) {
		
	}

}
