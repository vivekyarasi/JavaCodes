package com.java.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import com.java.mainclass.MainClass;

public class AppTest {
	/*@BeforeAll
	public static  void beforeAllmethod() {
		System.out.println("run once");
	}
	@BeforeEach
	public void meth2() {
		System.out.println("Before each method");
	}
	@AfterEach
	public void meth3() {
		System.out.println("After each method");
	}
	
	@Test
	public void meth1() {
		System.out.println("hello");
	}
	@Test
	public void meth4() {
		System.out.println("Hello_welcome");
	}
	*/
	/*
	@Test
	@DisplayName("Adding 2 nos")
	public void testaddMeth() {
		MainClass m=new MainClass();
		int actual=m.addMeth(5, 10);
		int expected=15;
		assertEquals(expected,actual);
	}*/
	static MainClass obj=null;
	@BeforeAll
	public static void before1()
	{
		obj=new MainClass();
	}
	@Test
	@DisplayName("checkString")
	public void testcheckString()
	{
		MainClass obj=new MainClass();
		boolean b=obj.checkString("Anil");
		assertTrue(b);
		
	}
	@ParameterizedTest
	@ValueSource(strings= {"ram","annu","banu"})
	public void testcheckString(String str)
	{
		
		boolean b=obj.checkString(str);
		assertTrue(b);
		
	}
	@Test
	@Tag("dev")
	public void method7() {
		System.out.println("kbckdJJCGUAGGCLGIFGIGGIK");
	}

}
