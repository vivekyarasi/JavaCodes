package com.java.predefined;

import java.util.function.BiFunction;

public class StaticMethRef {
	
	static int meth(int a,int b) {
		return a+b;
	}
	public static void main(String[] args) {
		BiFunction<Integer, Integer, Integer> fun1=StaticMethRef::meth;
		System.out.println(fun1.apply(10, 20));
		
	}

}
