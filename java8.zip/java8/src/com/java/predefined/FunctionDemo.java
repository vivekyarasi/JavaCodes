package com.java.predefined;

import java.util.*;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class FunctionDemo  {
	public static void main(String[] args) {
		

 Function<Integer, Double> obj=(x) -> x/2.3;
 	Double d=obj.apply(50);
 	System.out.println(d);
 	
 	Consumer<Integer> co=i->System.out.println("this is Consumer "+ i);
 	co.accept(10);
	
 	
 	Supplier<String> su=()->"Vivek Supplier";
 	System.out.println(su.get());
 	
 	Predicate<String> pre=
	}

	
	

	

}
