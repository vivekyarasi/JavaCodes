package com.java.predefined;

import java.util.function.Function;

public class MethodReference {
	public static void main(String[] args) {
		Function<Integer, Double> f=Math::sqrt;
		System.out.println(f.apply(4));
	}

}
