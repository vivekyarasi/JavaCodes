package com.java.lamdaexpressions;

class ThreadDemo implements Runnable{

	@Override
	public void run() {

System.out.println("Run Method called...........");
		
	}
	
}


public class RunnablelamdaExample {
	public static void main(String[] args) {
		Thread th=new Thread(new ThreadDemo());
		th.start();
		
		Thread lamda=new Thread(() -> System.out.println
			("Run method called using lamda"));
		lamda.start();
		
	


}
}
