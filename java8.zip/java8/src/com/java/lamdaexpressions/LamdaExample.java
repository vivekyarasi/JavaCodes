package com.java.lamdaexpressions;


//method passing zero parameters
interface Shape{
	void drop();
	
	default void meth() {
		System.out.println("Default");
	}
	static void meth2() {
		System.out.println("Static");
	}
}

class Rectangular implements Shape{

	@Override
	public void drop() {
		System.out.println("Rectangular class:draw() method");
		
	}
	
}
class Square implements Shape{

	@Override
	public void drop() {
		System.out.println("Square class:draw() method");
		
	}
	
}

class Circle implements Shape{

	@Override
	public void drop() {
		System.out.println("Circle class:draw() method");
		
	}
	
}

public class LamdaExample {
	public static void main(String[] args) {
		
	
		Shape s1=()-> System.out.println("vivek");
		s1.meth();
		
		
		
		
		
			
		
	Shape rectangle= ()-> System.out.println("Rectangular class:draw() method");
	rectangle.drop();
	
	
	
	
	Shape square=() -> System.out.println("Square class:draw() method");
	//square.drop();	
	
	
	
	Shape circle=() ->System.out.println("Circle class:draw() method");
	//circle.drop();
	
//	print(rectangle);
//	print(square);
//	print(circle);
	print(()-> System.out.println("Rectangular class:draw() method"));
	print(() -> System.out.println("Square class:draw() method"));
	print(() ->System.out.println("Circle class:draw() method"));
	
	
	
}
	private static void print(Shape shape) {
		shape.drop();
	}
}
