package com.java.streamapi;

import java.util.Arrays;
import java.util.List;

public class TerminalOperators {
	public static void main(String[] args) {
		List<Integer> list=Arrays.asList(2,4,6,7,5,11,13,14,17,19,21,25,26,19,35,45,55,64,78,89,97);
		System.out.println("=======aggrigate Operations==========");
		int i=list.stream().max(Integer::compare).get();
		System.out.println("max number = "+i);
		
		int i1=list.stream().min(Integer::compare).get();
		System.out.println("min number = "+i1);
		
		
		long l=list.stream().count();
		System.out.println("count = "+l);
		
		
		int i4=list.stream().mapToInt(Integer::intValue).sum();
		System.out.println("maptoint = "+i4);
		
		Double d=list.stream().mapToDouble(Integer::doubleValue).average().getAsDouble();
		System.out.println("maptodouble = "+d);
		
		System.out.println("=============find====================================");
		
		Integer findany=list.stream().findAny().get();
		System.out.println(findany);
		
		Integer findfirst=list.stream().findFirst().get();
		System.out.println(findfirst);
		
		System.out.println("==============match=========================");
		boolean b=list.stream().allMatch(x->x<100);
		System.out.println("allMatch = "+b);
		
	}

}
