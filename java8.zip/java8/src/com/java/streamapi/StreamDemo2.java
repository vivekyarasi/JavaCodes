package com.java.streamapi;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Stream;

public class StreamDemo2 {
	public static void main(String[] args) {
		List<String> l1=Arrays.asList("vivek","vikas","avijit");
		//l1.stream().map(String::toUpperCase).forEach(System.out::println);
		l1.stream().sorted().forEach(System.out::println);
		l1.stream().sorted(Comparator.reverseOrder()).forEach(System.out::println);
		
		System.out.println("=========================");
		Stream<String> st=Stream.of("java","python");
		//st.forEach(System.out::println);
		boolean v=st.noneMatch(x->x.contains("a"));
		System.out.println(v);
//		
//		Stream<String> stream=Arrays.stream(st);
//		stream.forEach(System.out::println);
		
		
		
		
	}

}
