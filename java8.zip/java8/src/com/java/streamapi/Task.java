package com.java.streamapi;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Task {
	public static void main(String[] args) {
		List<Integer> li=Arrays.asList(1,2,3,4,5,6,7,8,9,10);
		long even=li.stream().filter(x->x%2==0).count();
		System.out.println("even count is = "+even);
		
		long odd=li.stream().filter(x->x%2!=0).count();
		System.out.println("odd count is = "+odd);
		
		

		Map<String, Long> m=new HashMap();
		m.put("even",  even);
		m.put("odd", odd);
		System.out.println(m.get("even"));
		System.out.println(m.get("odd"));
		
		
	}

}
