package com.java.streamapi;

import java.util.List;

public class ListToArray{
    public static void main(String[] args) {
        List<String> list = List.of("Apple", "Banana", "Cherry");

        String[] array = list.toArray(String[]::new);
        for (String fruit : array) {
            System.out.println(fruit);
        }
    }
}
