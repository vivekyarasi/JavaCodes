package com.java.streamapi;

import java.util.*;

public class StreamDemo {
public static void main(String args[])
{
	List<Integer> l=Arrays.asList(4,5,6,7,8);
	//Stream<Integer>s=l.stream();
	//s.forEach(x->System.out.println(x));
	//s.forEach(System.out::println);
//	l.stream().forEach(x->System.out.println(x));
	//print all
	l.stream().forEach(System.out::println);
	
	int s=l.stream().filter(x->x>4).mapToInt(x->x).sum();
	System.out.println("sum is"+s);
	
	//l.stream().filter(x->x>4).mapToInt(x->x).forEach(System.out::println);
	
	//l.stream().filter(x -> x%2==0).forEach(System.out::println);//even
	//l.stream().filter(x -> x%2!=0).forEach(System.out::println);//odd
	
}
}

