package java8;

public interface TeamLead {
	public void workingHours();
	
	default public String role() {
		return "I'm TeamLead";
	}
	static String project() {
		return "IndusInd bank";
		
	}

}
