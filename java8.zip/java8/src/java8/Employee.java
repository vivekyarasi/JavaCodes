package java8;

public class Employee implements Manager,TeamLead{
	@Override
	public void workingHours() {
		System.out.println("9 working hrs");
	}
//	@Override
//	public String role() {
//		return Manager.super.role();
//	}
	public String role() {
		return TeamLead.super.role();
	}
	
	public static void main(String[] args) {
		Employee e=new Employee();
		e.workingHours();
		System.out.println(e.role());
		System.out.println(Manager.project());
		System.out.println(TeamLead.project());
	}
	
	

}
