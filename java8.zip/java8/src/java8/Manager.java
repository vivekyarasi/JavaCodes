package java8;

public interface Manager {
	public void workingHours();
	
	default public String role() {
		return "I'm Manager";
	}
	static String project() {
		return "Yes Bank";
		
	}

}
