package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.demo.model.Author;

public interface AuthorRepository extends JpaRepository<Author, Long> {
	
	 @Query("SELECT a FROM Author a WHERE SIZE(a.books) > :bookCount")
	    List<Author> findAuthorsWithMoreThanBooks(@Param("bookCount") int bookCount);
	
	

}
