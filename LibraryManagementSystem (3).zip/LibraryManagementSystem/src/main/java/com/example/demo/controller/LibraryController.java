package com.example.demo.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Author;
import com.example.demo.model.Book;

import com.example.demo.service.LibraryService;

@RestController
@RequestMapping("/library")
public class LibraryController {
	
	@Autowired
	LibraryService service;
	//Add Author
	@PostMapping("/author")
    public ResponseEntity<Author> createAuthor(@RequestBody Author author) {
        return ResponseEntity.ok(service.saveAuthor(author));
    }
	//AddBook
	 @PostMapping("/book")
	    public ResponseEntity<Book> createBook(@RequestBody Book book) {
	        return ResponseEntity.ok(service.saveBook(book));
	    }
	 // Get By id
	 @GetMapping("/authors/{authorId}")
	    public ResponseEntity<List<Book>> getBooksByAuthor(@PathVariable Long authorId) {
	        return ResponseEntity.ok(service.getBooksByAuthor(authorId));
	    }
	 //Update By id
	 @PutMapping("/{id}")
	    public Book updateById(@PathVariable("id") Long id,Book book1) {
			return service.UpdateById(id,book1);
	    	
	    }
	 	//Delete By id
	    @DeleteMapping("/book/{bookId}")
	    public ResponseEntity<Void> deleteBook(@PathVariable Long bookId) {
	        service.deleteBookById(bookId);
	        return ResponseEntity.noContent().build();
	    }

	    @GetMapping("/books/year/{year}")
	    public ResponseEntity<List<Book>> findBooksAfterYear(@PathVariable int year) {
	        LocalDate date = LocalDate.of(year, 1, 1);
	        return ResponseEntity.ok(service.findBooksPublishedAfter(date));
	    }

	    @GetMapping("/authors/books/{count}")
	    public ResponseEntity<List<Author>> findAuthorsWithMoreBooks(@PathVariable int count) {
	        return ResponseEntity.ok(service.findAuthorsWithMoreThanBooks(count));
	    }
	    

	    
	    
	    
	    

}
