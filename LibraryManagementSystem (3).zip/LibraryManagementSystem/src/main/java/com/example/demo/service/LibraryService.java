package com.example.demo.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Author;
import com.example.demo.model.Book;
import com.example.demo.repository.AuthorRepository;
import com.example.demo.repository.BookRepository;

@Service
public class LibraryService {
	
	@Autowired
	BookRepository bookrepository;
	
	@Autowired
	AuthorRepository authorrepository;

	 public Author saveAuthor(Author author) {
		 for(Book b:author.getBooks())
		 {
			 b.setAuthor(author);
		 }
	        return authorrepository.save(author);
	    }

	    public Book saveBook(Book book) {
	        return bookrepository.save(book);
	    }
	    
	    
	    
	    
	    public List<Book> getBooksByAuthor(Long authorId) {
	        return bookrepository.findByAuthor_Id(authorId);
	    }
	    
	    public Book UpdateById(Long id, Book book1) {
			Optional<Book> book=bookrepository.findById(id);
			if(book.isPresent()) {
				Book bok=book.get();
			bok.setAuthor(book1.getAuthor());
			bok.setIsbn(book1.getIsbn());
			bok.setTitle(book1.getTitle());
			return bookrepository.save(bok);
			}else {
				return null;
			}
			
		}

	    public void deleteBookById(Long bookId) {
	    	bookrepository.deleteById(bookId);
	    }

	    public List<Book> findBooksPublishedAfter(LocalDate year) {
	        return bookrepository.findBooksPublishedAfter(year);
	    }

	    public List<Author> findAuthorsWithMoreThanBooks(int bookCount) {
	        return authorrepository.findAuthorsWithMoreThanBooks(bookCount);
	    }

		


}
