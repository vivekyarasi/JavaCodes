package polymorphism;

public class BankAccount {
	private int accNumber;
	private String holderName;
	private int bal;
	static double intrest=5.5;
	
	public BankAccount(int accNumber, String holderName, int bal) {
		
		this.accNumber = accNumber;
		this.holderName = holderName;
		this.bal = bal;
	}
	
public void diplay() {
	System.out.println(accNumber+" "+holderName+" "+bal+" "+intrest);
}
	


	@Override
public String toString() {
	return "BankAccount [accNumber=" + accNumber + ", holderName=" + holderName + ", bal=" + bal + "]";
}

	public static void main(String[] args) {
		BankAccount b=new BankAccount(101,"a",5000);
		BankAccount b1=new BankAccount(102,"b",3000);
		BankAccount b2=new BankAccount(103,"c",5000);
//		b.diplay();
//		b1.diplay();
//		b2.diplay();
		System.out.println(b);
		
	}

}
