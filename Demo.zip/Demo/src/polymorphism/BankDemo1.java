package polymorphism;

//BankAccount class
class BankAccount1 {
 // Static variable (shared across all accounts)
 private static double interestRate = 3.5; // Default interest rate

 // Instance variables (specific to each account)
 private String accountNumber;
 private String accountHolder;
 private double balance;

 // Constructor to initialize account
 public BankAccount1(String accountNumber, String accountHolder, double balance) {
     this.accountNumber = accountNumber;
     this.accountHolder = accountHolder;
     this.balance = balance;
 }

 // Method to deposit money
 public void deposit(double amount) {
     if (amount > 0) {
         balance += amount;
         System.out.println(accountHolder + " deposited $" + amount);
     } else {
         System.out.println("Invalid deposit amount.");
     }
 }

 // Method to withdraw money
 public void withdraw(double amount) {
     if (amount > 0 && amount <= balance) {
         balance -= amount;
         System.out.println(accountHolder + " withdrew $" + amount);
     } else {
         System.out.println("Insufficient balance or invalid withdrawal amount.");
     }
 }

 // Static method to set the interest rate for all accounts
 public static void setInterestRate(double rate) {
     interestRate = rate;
     System.out.println("New interest rate set to: " + rate + "%");
 }

 // Method to display account details
 public void displayAccountDetails() {
     System.out.println("\nAccount Number: " + accountNumber);
     System.out.println("Account Holder: " + accountHolder);
     System.out.println("Balance: $" + balance);
     System.out.println("Current Interest Rate: " + interestRate + "%");
 }
}

//Main class to test functionality
public class BankDemo1 {
 public static void main(String[] args) {
     // Creating two bank accounts
     BankAccount1 account1 = new BankAccount1("123456", "Alice", 5000);
     BankAccount1 account2 = new BankAccount1("789012", "Bob", 3000);

     // Performing transactions
     account1.deposit(1000);
     account2.withdraw(500);

     // Displaying account details before interest rate change
     System.out.println("\n--- Before Interest Rate Change ---");
     account1.displayAccountDetails();
     account2.displayAccountDetails();

     // Changing the interest rate (affects all accounts)
     BankAccount1.setInterestRate(4.5);

     // Displaying account details after interest rate change
     System.out.println("\n--- After Interest Rate Change ---");
     account1.displayAccountDetails();
     account2.displayAccountDetails();
 }
}

