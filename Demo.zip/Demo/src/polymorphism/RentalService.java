package polymorphism;

class Vehicle {//upcasting Generalization
    void start() {
        System.out.println("Vehicle is starting...");
    }
}

class Car extends Vehicle {
    void openSunroof() {
        System.out.println("Sunroof opened!");
    }
}

class Bike extends Vehicle {
    void kickStart() {
        System.out.println("Bike kick-started!");
    }
}

public class RentalService {
    public static void main(String[] args) {
        Vehicle v1 = new Car();  // Upcasting (Car → Vehicle)
        Vehicle v2 = new Bike(); // Upcasting (Bike → Vehicle)

        v1.start();  // ✅ Calls Vehicle's start method
        v2.start();  // ✅ Calls Vehicle's start method

        // v1.openSunroof();  ❌ Not Allowed (Compile Error)
    }
}

