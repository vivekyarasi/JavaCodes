package polymorphism;

public class RentalService1 {//DownCasting specialization
    public static void main(String[] args) {
        Vehicle v1 = new Car();  // Upcasting
        Vehicle v2 = new Bike(); // Upcasting
        
        // Downcasting
        if (v1 instanceof Car) { 
            Car c = (Car) v1; // Downcasting Vehicle → Car
            c.openSunroof();  // ✅ Allowed after downcasting
        }

        if (v2 instanceof Bike) {
            Bike b = (Bike) v2; // Downcasting Vehicle → Bike
            b.kickStart();  // ✅ Allowed after downcasting
        }
    }
}

