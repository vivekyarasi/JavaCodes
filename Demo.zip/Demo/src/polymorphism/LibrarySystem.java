package polymorphism;


class LibraryItem {
    protected String title;
    protected String author;
    protected int yearPublished;
    
    
public LibraryItem(String title, String author, int yearPublished) {
		super();
		this.title = title;
		this.author = author;
		this.yearPublished = yearPublished;
	}

public void displayDetails() {
    System.out.println("Title: " + title);
    System.out.println("Author: " + author);
    System.out.println("Year Published: " + yearPublished);
}
}




class Book extends LibraryItem {
    private String genre;

    // Constructor
    public Book(String title, String author, int yearPublished, String genre) {
        super(title, author, yearPublished);
        this.genre = genre;
    }

    // Overriding displayDetails()
    @Override
    public void displayDetails() {
        super.displayDetails();  // Calls LibraryItem's displayDetails()
        System.out.println("Genre: " + genre);
    }
}
 class Magazine extends LibraryItem {
	    private int issueNumber;

	    // Constructor
	    public Magazine(String title, String author, int yearPublished, int issueNumber) {
	        super(title, author, yearPublished);
	        this.issueNumber = issueNumber;
	    }

	    // Overriding displayDetails()
	    @Override
	    public void displayDetails() {
	        super.displayDetails();  // Calls LibraryItem's displayDetails()
	        System.out.println("Issue Number: " + issueNumber);
	    }
	}
public class LibrarySystem {
	public static void main(String[] args) {
		 LibraryItem book = new Book("The Great Avijit Dam", "Avi Big Bull", 2017, "Romantic");
	        LibraryItem magazine = new Magazine("National Geographic", "National Geographic Society", 2024, 120);

	        System.out.println("Book Details:");
	        book.displayDetails();
	        
	        System.out.println("Magzine details");
	        magazine.displayDetails();
		
	}

}

