package polymorphism;

public class Employee {
	int id;
	

}
