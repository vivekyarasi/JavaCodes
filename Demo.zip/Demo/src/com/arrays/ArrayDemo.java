package com.arrays;

import java.util.Scanner;

public class ArrayDemo {
public static void main(String[] args) {
	int arr[]=new int[5];
	Scanner sc=new Scanner(System.in);
	//int i=sc.nextInt();
	for(int i1=0; i1<arr.length;i1++) {
		System.out.println(arr[i1]);
		
	}
}
}
