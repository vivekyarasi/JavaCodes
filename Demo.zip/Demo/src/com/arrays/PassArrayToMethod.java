package com.arrays;

public class PassArrayToMethod {
	int  meth(int m[]) {
		int sum=0;
		for(int x:m)
		{
			sum=sum+x;
		}
		return sum;
		
	}
	public static void main(String[] args) {
		int arr[]= {1,2,3,4,5};
		PassArrayToMethod  obj=new PassArrayToMethod();
		System.out.println(obj.meth(arr));

	}

}
