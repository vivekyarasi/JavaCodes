package com.arrays;

public class TwoArray {
	public static void main(String[] args) {
		int arr;
	}
	

}
