package com.java.book;

import java.util.List;
import java.util.stream.Collectors;

class Car {
    private String name;      // Private data fields
    private String carName;
    private double price;

    // Parameterized constructor
    public Car(String name, String carName, double price) {
        this.name = name;
        this.carName = carName;
        this.price = price;
    }

    // Getter methods
    public String getName() {
        return name;
    }

    public String getCarName() {
        return carName;
    }

    public double getPrice() {
        return price;
    }

    // Setter methods
    public void setName(String name) {
        this.name = name;
    }

    public void setCarName(String carName) {
        this.carName = carName;
    }

    public void setPrice(double price) {
        this.price = price;
    }
}

// Definition of CarImplementation class


class CarImplementation {

    // Method to calculate the sum of car prices
    public double sumOfPrices(List<Car> carList) {
        return carList.stream()
                      .map(Car::getPrice)  // Map each Car object to its price
                      .reduce(0.0, Double::sum); // Reduce to get the sum of prices
    }

    // Method to get the list of car names with prices above 25000
    public List<String> printName(List<Car> carList) {
        return carList.stream()
                      .filter(car -> car.getPrice() > 25000)  // Filter cars with price > 25000
                      .map(Car::getCarName)   // Map each Car object to its carName
                      .collect(Collectors.toList()); // Collect names into a list
    }

    // Method to get the maximum car price
    public double maxPrice(List<Car> carList) {
        return carList.stream()
                      .map(Car::getPrice)  // Map each Car object to its price
                      .reduce(0.0, Double::max); // Reduce to get the maximum price
    }
}
