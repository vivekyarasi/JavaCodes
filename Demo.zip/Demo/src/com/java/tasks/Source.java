package com.java.tasks;

import java.util.Scanner;

class ColourCodeValidator {
    // Method to validate Hexadecimal Color Code
    public static int validateHexCode(String code) {
        if (code.matches("#[A-Fa-f0-9]{6}")) {
            return 1; // Valid code
        }
        return -1; // Invalid code
    }

    // Method to validate Decimal RGB Color Code
    public static int validateDecimalCode(String code) {
        if (code.matches("rgb\\((\\d{1,3}),(\\d{1,3}),(\\d{1,3})\\)")) {
            String[] values = code.substring(4, code.length() - 1).split(",");
            for (String value : values) {
                int num = Integer.parseInt(value.trim());
                if (num < 0 || num > 255) {
                    return -1; // Invalid code
                }
            }
            return 1; // Valid code
        }
        return -1; // Invalid code
    }
}

public class Source {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Taking user input
        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        if (choice == 1 || choice == 2) {
            String inputCode = scanner.nextLine(); // Read color code

            int result = (choice == 1) 
                        ? ColourCodeValidator.validateHexCode(inputCode) 
                        : ColourCodeValidator.validateDecimalCode(inputCode);

            System.out.println(result == 1 ? "Valid Code" : "Invalid Code");
        } else {
            System.out.println("Invalid choice");
        }

        scanner.close();
    }
}

