package com.java.tasks;

//StringPlay class-----1
class StringPlay {
 int convert; // To store integer conversion result
 int max;     // To store maximum occurrence of a character

 // Public empty constructor
 public StringPlay() {
 }
}

//StringMethods class
class StringMethods {
 // Method to convert string to integer and assign to sp.convert
 public int convertToInt(StringPlay sp, String str) {
     sp.convert = Integer.parseInt(str); // Convert string to int
     return sp.convert;
 }

 // Method to count occurrences of a character and assign to sp.max
 public int getMax(StringPlay sp, String str, char ch) {
     int count = 0;
     for (char c : str.toCharArray()) {
         if (c == ch) {
             count++;
         }
     }
     sp.max = count; // Assign count to sp.max
     return count;
 }
}

//Main class to test the implementation
public class StringPlayDemo {
 public static void main(String[] args) {
     // Creating instances
     StringMethods sm = new StringMethods();
     StringPlay sp = new StringPlay();

     // Testing getMax method
     System.out.println(sm.getMax(sp, "fgfgfgf", 'g')); // Output: 3

     // Testing convertToInt method
     System.out.println(sm.convertToInt(sp, "123")); // Output: 123
 }
}

