package com.java.tasks;

import java.util.regex.*;

class Student {
    String name;
    String usn;
    String college;
    int cgpa;

    // Constructor to initialize the student object
    public Student(String name, String usn, String college, int cgpa) {
        this.name = name;
        this.usn = usn;
        this.college = college;
        this.cgpa = cgpa;
    }
}

class StudentImplementation {
    // Method to extract student details from the given string
    public Student getStudentInfo(String str) {
        String[] parts = str.split("[@#-]");
        String name = parts[0];
        String usn = parts[1];
        String college = parts[2];
        int cgpa = Integer.parseInt(parts[3]);

        return new Student(name, usn, college, cgpa);
    }

    // Method to determine student section based on USN
    public String getStudentSection(Student s) {
        String lastThreeDigits = s.usn.substring(s.usn.length() - 3);
        int usnNum = Integer.parseInt(lastThreeDigits);

        if (usnNum >= 1 && usnNum <= 60) {
            return "A";
        } else if (usnNum >= 61 && usnNum <= 120) {
            return "B";
        } else if (usnNum >= 121 && usnNum <= 180) {
            return "C";
        } else {
            return "Z";
        }
    }
}

public class Source1 {
    public static void main(String[] args) {
        // Sample input
        String input = "Amit Rai@1PC16CS046-ALU#8";
        
        StudentImplementation si = new StudentImplementation();
        
        // Extract student details
        Student student = si.getStudentInfo(input);
        
        // Get student section
        String section = si.getStudentSection(student);
        
        // Output results
        System.out.println("Name: " + student.name);
        System.out.println("USN: " + student.usn);
        System.out.println("College: " + student.college);
        System.out.println("CGPA: " + student.cgpa);
        System.out.println("Section: " + section);
    }
}

