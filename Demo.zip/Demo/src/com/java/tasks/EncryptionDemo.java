package com.java.tasks;

class Encryption {
    // Method to decode a message by removing vowels
    public String decodeMessage(String message) {
        return message.replaceAll("[AEIOUaeiou]", ""); // Removing vowels
    }

    // Method to encode a message by inserting vowels cyclically
    public String encodeMessage(String message) {
        char[] vowels = {'a', 'e', 'i', 'o', 'u'};
        int vowelIndex = 0; // To cycle through vowels
        StringBuilder encodedMessage = new StringBuilder();

        for (char ch : message.toCharArray()) {
            if (ch == ' ') { 
                // Keep spaces unchanged
                encodedMessage.append(ch);
            } else { 
                // Append original character
                encodedMessage.append(ch);

                // Append next vowel in the cycle
                encodedMessage.append(vowels[vowelIndex]);

                // Move to next vowel cyclically
                vowelIndex = (vowelIndex + 1) % vowels.length;
            }
        }
        return encodedMessage.toString();
    }
}

// Main class to test the implementation
public class EncryptionDemo {
    public static void main(String[] args) {
        Encryption obj = new Encryption();

        // Testing decodeMessage method
        System.out.println(obj.decodeMessage("oriGinal MessAge")); // Output: rGnl Mssg

        // Testing encodeMessage method
        System.out.println(obj.encodeMessage("QWRT cvbN MnKL")); // Output: QaWeRiTo cuvabeNi MonuKaLe
    }
}

