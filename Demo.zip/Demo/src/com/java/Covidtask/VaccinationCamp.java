package com.java.Covidtask;

import java.util.ArrayList;
import java.util.*;

public class VaccinationCamp {
	
	
	
	
	 ArrayList<Vaccine> list = new ArrayList<>();

	    public void assignVaccine() {
	        for (Vaccine v : list) {
	            if (v.getAge() >= 45) {
	                v.setDosage(250);
	            } else if (v.getAge() >= 20) {
	                v.setDosage(200);
	            } else {
	                v.setDosage(100);
	            }
	        }
	    }

	    public float vaccineInjected() {
	        float totalDosage = 0;
	        for (Vaccine v : list) {
	            totalDosage += v.getDosage();
	        }
	        return totalDosage;
	    }
public static void main(String[] args) {
	VaccinationCamp v=new VaccinationCamp();
	v.list.add(new Vaccine(49));
	v.list.add(new Vaccine(26));
	v.list.add(new Vaccine(19));
	v.assignVaccine();
	System.out.println("Total Dosage = "+v.vaccineInjected());
	
    
     

 
 }

}

