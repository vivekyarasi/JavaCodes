package com.java.map;

import java.util.HashMap;
import java.util.Map;

public class MapDemo {
	public static void main(String[] args) {
		Map<Integer, String> m=new HashMap();
		m.put(1, "vikas");
		m.put(2, "vivek");
		m.put(3, "suman");
		m.put(null, "vivek");
		System.out.println(m.get(null));
		System.out.println(m.get(2));
		System.out.println(m);
		System.out.println(m.size());
	}

}
