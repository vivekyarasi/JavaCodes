package com.java.map;

import java.util.*;

public class InsurancePolicyManager {
	private TreeMap<Integer, String> policyMap;

	
	
	 public InsurancePolicyManager(TreeMap<Integer, String> policyMap) {
		 this.policyMap = policyMap;
	}

	public void addPolicyDetails(int policyId, String policyName) {
	        policyMap.put(policyId, policyName);
	    }
	 public void displayAllPolicies() {
	        for (Map.Entry<Integer, String> entry : policyMap.entrySet()) {
	            System.out.println(entry.getKey() + " " + entry.getValue());
	        }
	 }
	 public List<Integer> searchBasedOnPolicyType(String policyType) {
	        List<Integer> matchingPolicies = new ArrayList<>();
	        for (Map.Entry<Integer, String> entry : policyMap.entrySet()) {
	            if (entry.getValue().toLowerCase().contains(policyType.toLowerCase())) {
	                matchingPolicies.add(entry.getKey());
	            }
	        }
	        return matchingPolicies;
	    }
	

		public static void main(String[] args) {
			 Scanner scanner = new Scanner(System.in);
		        InsurancePolicyManager manager = new InsurancePolicyManager();

		        // Adding predefined policy details
		        manager.addPolicyDetails(10654, "Max Bupa Health Insurance");
		        manager.addPolicyDetails(10321, "SBI Health Insurance");
		        manager.addPolicyDetails(20145, "IFFCO Tokio Two Wheeler Insurance");
		        manager.addPolicyDetails(20165, "New India Assurance Two Wheeler Insurance");
		        manager.addPolicyDetails(10110, "Reliance Health Insurance");
		        System.out.println("Display Polotics");
		        manager.displayAllPolicies();
		        
		        System.out.println("Enter policy type to search: ");
		        String policyType = scanner.nextLine();
		        List<Integer> result = manager.searchBasedOnPolicyType(policyType);

		      
		        if (result.isEmpty()) {
		            System.out.println("No policies found for the given type.");
		        } else {
		            for (Integer policyId : result) {
		                System.out.println(policyId);
		            }
		        }
		        
		}
	}


