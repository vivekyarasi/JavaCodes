package com.java.map;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class HashMapDemo {
//	private static List Integer;

	public static void main(String[] args) {
		Map<String, Integer> m= new HashMap();
		m.put("vikas", 101);
		m.put("vivek", 102);
		m.put("suman", 103);
		m.put("chinna", 104);
		m.put("vikram", 105);
		
		for(Entry<String, Integer> en:m.entrySet()) {
			System.out.println(en.getKey()+"  "+en.getValue());
			
			
		}
		
		
	}

}
