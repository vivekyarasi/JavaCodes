package com.java.sorting;

import java.util.*;
public class StringSorting {

	public static void main(String[] args) {
		List<String> l=Arrays.asList("ben","den","ann");
		Collections.sort(l);
		System.out.println(l);

	}

}
