package com.java.sorting;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class IntegerSorting {
	

		public static void main(String[] args) {
			List<Integer> l=Arrays.asList(1,2,9,3,4);
			Collections.sort(l);
			System.out.println(l);

		}

	}


