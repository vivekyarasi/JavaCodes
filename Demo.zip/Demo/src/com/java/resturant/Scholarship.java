package com.java.resturant;

import java.util.*;

class Student{
	private String name;
	private String collegeName;
	private float percentage;
	private float scholarship;
	public Student(String name, String collegeName, float percentage) {
		super();
		this.name = name;
		this.collegeName = collegeName;
		this.percentage = percentage;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCollegeName() {
		return collegeName;
	}
	public void setCollegeName(String collegeName) {
		this.collegeName = collegeName;
	}
	public float getPercentage() {
		return percentage;
	}
	public void setPercentage(float percentage) {
		this.percentage = percentage;
	}
	public float getScholarship() {
		return scholarship;
	}
	public void setScholarship(float scholarship) {
		this.scholarship = scholarship;
	}
	@Override
	public String toString() {
		return "Student [name=" + name + ", collegeName=" + collegeName + ", percentage=" + percentage
				+ ", scholarship=" + scholarship + "]";
	}


	
}
class Portal {
    ArrayList<Student> studentList = new ArrayList<>();

    public void assignScholarship() {
        for (Student student : studentList) {
            if (student.getPercentage() >= 91) {
                student.setScholarship(10000);
            } else if (student.getPercentage() >= 81) {
                student.setScholarship(5000);
            } else {
                student.setScholarship(0);
            }
        }
    }

    public float totalScholarship() {
        float total = 0;
        for (Student student : studentList) {
            total += student.getScholarship();
        }
        System.out.println(total);
        return total;
    }

    public String totalMaxScholarshipOfCollege() {
        HashMap<String, Float> collegeScholarshipMap = new HashMap<>();
        
        for (Student student : studentList) {
            collegeScholarshipMap.put(student.getCollegeName(), 
                collegeScholarshipMap.getOrDefault(student.getCollegeName(), 0f) + student.getScholarship());
        }
        
        String maxCollege = "";
        float maxScholarship = 0;
        
        for (String college : collegeScholarshipMap.keySet()) {
            if (collegeScholarshipMap.get(college) > maxScholarship) {
                maxScholarship = collegeScholarshipMap.get(college);
                maxCollege = college;
            }
        }
        
        System.out.println(maxCollege);
        return maxCollege;
    }
}
public class Scholarship {
	  public static void main(String[] args) {
	        Portal obj = new Portal();
	        obj.studentList.add(new Student("Steve", "IIT", 89));
	        obj.studentList.add(new Student("Bob", "NIT", 94));
	        obj.studentList.add(new Student("Alice", "Abcd", 59));
	        
	        obj.assignScholarship();
	        obj.totalScholarship();
	        obj.totalMaxScholarshipOfCollege();
	    }
	}


