package com.java.resturant;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

class Restaurant {
    private String name;
    private String location;
    private String cuisine;
    private String rating;

    public Restaurant(String name, String location, String cuisine, String rating) {
        this.name = name;
        this.location = location;
        this.cuisine = cuisine;
        this.rating = rating;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getCuisine() {
        return cuisine;
    }

    public void setCuisine(String cuisine) {
        this.cuisine = cuisine;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    @Override
    public String toString() {
        return "Name:" + name + "\nLocation:" + location + "\nCuisine:" + cuisine + "\nRating:" + rating;
    }
}

class DAOLayer {
    public Restaurant searchRestaurant(ArrayList<Restaurant> restaurants, String info) {
        for (Restaurant restaurant : restaurants) {
            if (restaurant.getName().equalsIgnoreCase(info)) {
                return restaurant;
            }
        }
        return null;
    }

    public void addRestaurant(ArrayList<Restaurant> restaurantList) {
        Iterator<Restaurant> iterator = restaurantList.iterator();
        while (iterator.hasNext()) {
            System.out.println(iterator.next());
        }
    }
}

public class RestaurantApplication {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Restaurant> restaurantList = new ArrayList<>();
        DAOLayer dao = new DAOLayer();
        
        int choice = Integer.parseInt(scanner.nextLine());
        
        String name1 = scanner.nextLine();
        String location1 = scanner.nextLine();
        String cuisine1 = scanner.nextLine();
        String rating1 = scanner.nextLine();
        
        String name2 = scanner.nextLine();
        String location2 = scanner.nextLine();
        String cuisine2 = scanner.nextLine();
        String rating2 = scanner.nextLine();
        
        restaurantList.add(new Restaurant(name1, location1, cuisine1, rating1));
        restaurantList.add(new Restaurant(name2, location2, cuisine2, rating2));
        
        if (choice == 1) {
            dao.addRestaurant(restaurantList);
        } else if (choice == 2) {
            String searchName = scanner.nextLine();
            Restaurant found = dao.searchRestaurant(restaurantList, searchName);
            if (found != null) {
                System.out.println("Found:Name=" + found.getName() + ",Location=" + found.getLocation() + ",Cuisine=" + found.getCuisine() + ",Rating=" + found.getRating());
            } else {
                System.out.println("Restaurant not found");
            }
        }
        scanner.close();
    }
}
