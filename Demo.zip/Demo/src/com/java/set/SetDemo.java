package com.java.set;

import java.util.HashSet;
import java.util.*;

public class SetDemo {
	public static void main(String[] args) {
		Set s=new HashSet();//it doesnot maintain insertion order
		
		s.add("vivek");
		s.add("vikas");
		s.add("avijit");
		s.add(4);
		System.out.println(s.equals(s));
		System.out.println(s.hashCode());
	}

}
