package com.java.set;

import java.util.HashSet;
import java.util.*;

public class Task {
	public static void main(String[] args) {
		Set set=new HashSet() ;
			set.add("Hello");
	        set.add(42);
	        set.add(3.14);
	        set.add(true);
	        set.add("World");
	        System.out.println(set);
			
	
		
	
System.out.println("-------------------");
if(set.contains(42)) {
	System.out.println("42 it's Found");
	
}
System.out.println("--------------------------------");
set.remove("World");
System.out.println("-------------After Removing---------");
Iterator i1=set.iterator();
while(i1.hasNext()) {
	Object o=i1.next();
	System.out.println(o);
}
}
	
}