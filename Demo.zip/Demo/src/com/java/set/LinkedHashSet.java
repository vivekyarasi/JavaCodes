package com.java.set;

import java.util.HashSet;
import java.util.Set;

public class LinkedHashSet {
	public static void main(String[] args) {
		Set s=new java.util.LinkedHashSet();//it doesnot maintain insertion order
		
		s.add("vivek");
		s.add("vikas");
		s.add("avijit");
		s.add(4);
		System.out.println(s);
		System.out.println(s.equals(s));
		System.out.println(s.hashCode());
	}

}
