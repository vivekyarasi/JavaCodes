package com.java.exception;

import java.util.Scanner;

public class Exception {
	 public static void validateNumber(int num) throws IllegalArgumentException, ArithmeticException {
	        if (num < 0) {
	            throw new IllegalArgumentException("Negative number not allowed!");
	        } else if (num == 0) {
	            throw new ArithmeticException("Zero is not a valid input!");
	        } else {
	            System.out.println("Valid number entered: " + num);
	        }
	    }
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
				
		
        try {
            System.out.print("Enter an integer: ");
            int number = sc.nextInt(); // Read user input
            validateNumber(number); // Validate input
        } catch (IllegalArgumentException e) {
            System.out.println("Exception caught: " + e.getMessage());
        } catch (ArithmeticException e) {
            System.out.println("Exception caught: " + e.getMessage());
        } finally {
            
            System.out.println("Program execution completed.");
        }
    }

}
