package com.java.exception;

import java.util.Scanner;

public class FinallyDemo {
	public static void main(String[] args) {
		Scanner sc=null;
		try {
			sc=new Scanner(System.in);
			int a=sc.nextInt();
			int d=42/a;
			
		} /*catch (ArithmeticException e) {
			e.printStackTrace();
			
		}*/
		finally {
			sc.close();
			System.out.println("i am done");
		}
	}

}
