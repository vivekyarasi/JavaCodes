package com.java.exception;

import java.util.Scanner;

public class AbnormalTermination {
	public static void main(String[] args) {
		
	
	Scanner s=new Scanner(System.in);
	int a=s.nextInt();
	try {
	int d=42/a;
	System.out.println(d);
	}
	catch(ArithmeticException e) {
		e.printStackTrace();
		
	}
	
	System.out.println("hello");
}
	

}
