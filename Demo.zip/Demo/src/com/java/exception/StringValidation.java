package com.java.exception;

import java.util.Scanner;

class StringValidation {
    // Method to validate the input string
    public static void validateInput(String input) throws IllegalArgumentException, RuntimeException {
        if (input.isEmpty()) {
            throw new IllegalArgumentException("Input cannot be empty!");
        } else if (input.length() < 5) {
            throw new RuntimeException("Input must be at least 5 characters long!");
        } else {
            System.out.println("Valid input: " + input);
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        try {
            System.out.print("Enter a string: ");
            String userInput = scanner.nextLine(); // Read user input
            validateInput(userInput); // Validate input
        } catch (IllegalArgumentException e) {
            System.out.println("Exception caught: " + e.getMessage());
        } catch (RuntimeException e) {
            System.out.println("Exception caught: " + e.getMessage());
        } finally {
            scanner.close();
            System.out.println("Program execution completed.");
        }
    }
}
