package com.java.exception;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class TryWithResources {
	public static void checkString(String text) throws IllegalArgumentException,ArithmeticException{ }
    public static void main(String[] args) throws FileNotFoundException, IOException {
                try (Scanner scanner = new Scanner(System.in);
                		FileOutputStream fos=new FileOutputStream("c:/a.txt")) {
            System.out.print("Enter your name: ");
            String name = scanner.next();
            System.out.print("Enter your age: ");
            int age = scanner.nextInt();
            
            System.out.println("Hello, " + name + "! You are " + age + " years old.");
        } catch (ArithmeticException e) {
            System.out.println("An error occurred: " + e);
        } 
        
    
}
}

