package com.java.collections;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ArrayListDemo {
	public static void main(String[] args) {
		
		List l=new ArrayList();
		l.add(3);
		l.add(4.1f);
		l.add(1,"vviek");
		l.add("ken");
//		System.out.println(l.get(2));
//		System.out.println(l.indexOf(3));
//		System.out.println(l);
//		System.out.println(l.size());
//		System.out.println(l.toArray());
//		System.out.println(l.contains(3));
		
		//using foreach
//		for(Object s:l) {
//			System.out.println(s);
//		}
		
		Iterator i1=l.iterator()  ;
			while(i1.hasNext()) {
				Object obj=i1.next();
				System.out.println(obj);
				
				
			}
		}
		
	}


