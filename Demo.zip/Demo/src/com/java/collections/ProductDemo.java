package com.java.collections;

import java.util.LinkedList;
import java.util.List;

class Product{
	private int pid;
	private String pname;
	private int pprice;
	public Product(int pid, String pname, int pprice) {
		super();
		this.pid = pid;
		this.pname = pname;
		this.pprice = pprice;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public int getPprice() {
		return pprice;
	}
	public void setPprice(int pprice) {
		this.pprice = pprice;
	}
	@Override
	public String toString() {
		return "Product [pid=" + pid + ", pname=" + pname + ", pprice=" + pprice + "]";
	}
	
	
}

public class ProductDemo {
	public static void main(String[] args) {
		
	
	List<Product> pr=new LinkedList<Product>();
	Product p=new Product(101, "amul", 25);
	Product p1=new Product(102, "nandhini", 50);
	Product p2=new Product(103, "jersy", 45);
	pr.add(p);
	pr.add(p1);
	pr.add(p2);
	
	for(Product x:pr)
	{
		System.out.println(x.getPname());
		System.out.println(x.getPprice());
	}

}
}
