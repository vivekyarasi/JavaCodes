package com.java.collections;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Task {
	public static void main(String[] args) {
		List l=new ArrayList();
		l.add("java");
		l.add(100);
		l.add(3.14f);
		l.add("spring");
		l.add(true);
		
		for(Object ob:l) {
			System.out.println(ob);
			
			
		}
		l.remove(2);
		System.out.println("after remove");
		Iterator i1=l.iterator();
		while(i1.hasNext()) {
			Object o=i1.next();
			System.out.println(o);
		}
	}
	

}
