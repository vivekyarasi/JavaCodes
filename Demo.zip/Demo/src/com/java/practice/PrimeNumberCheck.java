package com.java.practice;

import java.util.Scanner;

public class PrimeNumberCheck {
	
	public static boolean isPrime(int num) {
		if(num <=1) {
			return false;
		}
		for(int i=2;i<num;i++) {
			if(num%i==0) {
				return false;
			}
		}
		return true;
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int num1=sc.nextInt();
		int num2=sc.nextInt();
		
		if(num1==num2) {
			System.out.println("0");
		}
		
		boolean isprime1=isPrime(num1);
		boolean isprime2=isPrime(num2);
		
		
		if(isprime1&&isprime2) {
			System.out.println(Math.max(num1, num2));
		}else {
			System.out.println(Math.min(num1, num2));
		}
		
	}

}
