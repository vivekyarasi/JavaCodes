package com.inherit;

public class Lion extends Animal {
	@Override
	void eat() {
		System.out.println("lion eat");
	}
	
	
	public static void main(String[] args) {
		Lion l=new Lion();
		l.eat();
		l.bark();
		
		
	}

}
