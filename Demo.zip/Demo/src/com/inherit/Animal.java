package com.inherit;

public class Animal {
	protected String name="Animal";
	void eat(){
		System.out.println(name);
		
	}
	void bark() {
		System.out.println("Animal barks");
	}
		
	

}
