package basics;

public class Bank {
//	void display(int id,String name,double amt){
//		//System.out.println("id = "+id+"name = "+name+" amount = "+amt);
//		
//		
//	}
	public static void main(String[] args) {
		Customer1 c=new Customer1(1, "vivek", 290.4);
		c.diplay();
		
	}

}
