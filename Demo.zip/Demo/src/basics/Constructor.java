package basics;

public class Constructor {
	//contructor should always start with class name ,it doesn't have any return type
	
	// 
	int id;
	String person;
	 Constructor(int i,String name){
		id=i;
		person=name;
	}
	 
	 Constructor(){
		 
	 }
	 void method() {
		 System.out.println(id);
		 System.out.println(person);
	 }
	public static void main(String[] args) {
		Constructor c=new Constructor(1, "vivek");
		c.method();
		
	}

}
