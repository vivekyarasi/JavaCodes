package basics;

public class MethodOverloading1 {
	
	 int id;
	 String name;
	 int sal;

	public void employee(int id,String name,int sal) {
		this.id=id;
		this.name=name;
		this.sal=sal;

		
	}
	public void employee(int id,String name,double sal) {
		this.id=id;
		this.name=name;
		this.sal =(int)sal;
		
		
	}
	
	public static void main(String[] args) {
		MethodOverloading1 md=new MethodOverloading1();
		md.employee(1, "vivek", 1000);
		md.employee(2, "vikas", 200000);
	}

}
