package basics;

public class Cube {
	int len,bre,hei;
	
	
	
	public Cube() {
		
	}
	
	public Cube(int len) {
		
		this.len = len;
		this.bre = len;
		this.hei = len;
	}



	public Cube(int len, int bre, int hei) {
		
		this.len = len;
		this.bre = bre;
		this.hei = hei;
	}



public int area() {
	return len*bre*hei;
	
}




	public static void main(String[] args) {
		Cube c=new Cube(10,20,30);
		System.out.println(c.area());
		
		Cube c2=new Cube();
		System.out.println(c2.area());
		
		Cube c3=new Cube(10);
		System.out.println(c3.area());
		
	}



	



	

}
