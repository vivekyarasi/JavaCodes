package basics;

import java.util.Scanner;

public class Input {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String s=sc.next();
		System.out.println("Enter name = "+s);
		Double d=sc.nextDouble();
		System.out.println("double = "+d);
	}

}
