package basics;

import java.util.Scanner;

public class Rectangle {
	
	int len,bre;
	void show(int p,int q) {
		len=p;
		bre=q;
		
		System.out.println("Area of rectangle ="+len*bre);
	}

	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		Integer i=sc.nextInt();
		Integer i1=sc.nextInt();
		
		Rectangle r=new Rectangle();
		r.show(i, i1);
	}

}
