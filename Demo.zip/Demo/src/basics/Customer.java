package basics;

class Customer1 {
	int id;
	String name;
	Double amt;
	public Customer1(int id, String name, Double amt) {
		
		this.id = id;
		this.name = name;
		this.amt = amt;
	}
	 public void diplay(){
		System.out.println("id = "+id+" name = "+name+"amount = "+amt);
		
	}
	 
	 
	 class Customer{
		 
	 }

}
