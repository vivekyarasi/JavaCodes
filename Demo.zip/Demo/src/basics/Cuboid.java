package basics;

import java.util.Scanner;

public class Cuboid {
	//declare len,br,h
	int length,breath,height;
	
	void area(int a,int b,int c){
		length=a;
		breath=b;
		height=c;
		System.out.println("Length = "+a);
		System.out.println("breath = "+b);
		System.out.println("height = "+c);
		System.out.println("area ="+a*b*c);
		
		
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		Cuboid c=new Cuboid();
		Integer i=sc.nextInt();
		Integer i2=sc.nextInt();
		Integer i3=sc.nextInt();
		c.area(i, i2, i3);
	}

}
