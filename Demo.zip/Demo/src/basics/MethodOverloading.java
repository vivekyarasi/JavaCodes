package basics;

public class MethodOverloading {
	
	public void diplay() {
		System.out.println("Zero parameters");
	}
	
	
	
	public void display(int i,String name) {
		System.out.println("id = "+i+" Name = "+name);
		
	}
	public static void main(String[] args) {
		MethodOverloading md=new MethodOverloading();
		md.diplay();
		md.display(1, "vivek");
	}

}
