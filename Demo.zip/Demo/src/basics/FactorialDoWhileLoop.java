package basics;

import java.util.Scanner;

public class FactorialDoWhileLoop {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in) ;
		System.out.println("Enter a number:");
		int num=sc.nextInt();
		int fact=1;
		int i=1;
		do {
			 fact *= i; // Multiply factorial by current value of i
	            i++; // Increment counter
			
		}while(i<=num);
		System.out.println("Factoial of "+num+" is "+fact);

	}

}
