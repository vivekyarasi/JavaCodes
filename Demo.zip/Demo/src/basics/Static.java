package basics;

public class Static {
	static int id=25;
	static void meth() {
		int id=10;
		System.out.println(id);
	}
	
	public static void main(String[] args) {
		int id=15;
		System.out.println(id);
		Static.meth();
		System.out.println(Static.id);
			
		}
 
	
	
	
	
	

	}


