package basics;

public class StudentTask {
	 int id;
	 String name;
	 String course;
	 
	 public StudentTask(int id, String name, String course) {
			
			this.id = id;
			this.name = name;
			this.course =course;

		}
	 void method(int id, String name,String course) {
		System.out.println("id ="+id+" name = "+name+" course = "+course);
		
		 
	 }
	 void display(int id, String name,String course) {
		 System.out.println("id ="+id+" name = "+name+" course = "+course);
	 }
	 void demo(int id, String name,String course) {
		 System.out.println("id ="+id+" name = "+name+" course = "+course);
	 }
	public static void main(String[] args) {
		StudentTask st=new StudentTask(1,"unknown","unknown");
		st.method(100, "unknown", "unknown");
		st.display(100, "vivek", "unknown");
		st.demo(100, "vivek", "unknown");
		
		
		 
	}
	

}
