package basics;

import java.util.Scanner;

public class FactorialWhileLoop {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in) ;
		System.out.println("Enter a number:");
		int num=sc.nextInt();
		int fact=1;
		int i=1;  //intialization loop
		while(i<=num) {
			fact *=i;
			i++;//increment
		
	}
		System.out.println("Factoial of "+num+" is "+fact);

}
}
