package string;

public class StringDemo {
	
	public static void main(String[] args) {
		String s="vivek";
		String s1="vivek";
		String a=s.toUpperCase();
		System.out.println(a);
		System.out.println(a.charAt(2));
		System.out.println(a.concat(" yarasi"));
		System.out.println(a.isEmpty());
		System.out.println(s.equals(s1));
	}

}
