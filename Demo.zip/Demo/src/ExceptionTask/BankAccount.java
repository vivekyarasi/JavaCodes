package ExceptionTask;

//Custom checked exception for insufficient funds
class InsufficientFundsException extends Exception {
 public InsufficientFundsException(String message) {
     super(message);
 }
}

//Custom unchecked exception for invalid withdrawal amount
class InvalidAmountException extends RuntimeException {
 public InvalidAmountException(String message) {
     super(message);
 }
}

public class BankAccount {
	private double balance;

    // Constructor to initialize account balance
    public BankAccount(double balance) {
        this.balance = balance;
    }

    // Method to withdraw money
    public void withdraw(double amount) throws InsufficientFundsException {
        if (amount <= 0) {
            throw new InvalidAmountException("Withdrawal amount cannot be negative or zero.");
        }
        if (amount > balance) {
            throw new InsufficientFundsException("Insufficient funds. Available balance: " + balance);
        }
        balance -= amount;
        System.out.println("Withdrawal successful. Remaining balance: " + balance);
    }

    // Method to get balance
    public double getBalance() {
        return balance;
    }
}


