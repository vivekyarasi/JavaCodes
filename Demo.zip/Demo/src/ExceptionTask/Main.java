package ExceptionTask;

public class Main {
	public static void main(String[] args) throws InsufficientFundsException {
		BankAccount account = new BankAccount(500); // Initial balance: 500

        try {
            account.withdraw(-100); // Negative withdrawal test
        } catch (InvalidAmountException e) {
            System.out.println("Exception: " + e.getMessage());
        }

        try {
            account.withdraw(600); // Exceeding balance test
        } catch (InsufficientFundsException e) {
            System.out.println("Exception: " + e.getMessage());
        }

        try {
            account.withdraw(300); // Successful withdrawal
        } catch (InsufficientFundsException e) {
            System.out.println("Exception: " + e.getMessage());
        }
    }
	}


