package abstract1;

class Loan1 {
    public double calculateLoanAmount(Employee employeeObj) {
        if (employeeObj instanceof PermanentEmployee) {
            return employeeObj.getSalary() * 0.15;  // 15% loan for permanent employees
        } else if (employeeObj instanceof TemporaryEmployee) {
            return employeeObj.getSalary() * 0.10;  // 10% loan for temporary employees
        }
        return 0;
    }
}
