package abstract1;

public final class FinalVariable {
	final int val ;
	
	public FinalVariable(int val) {
		
		this.val = val;
	}

	@Override
	public String toString() {
		return "FinalVariable [val=" + val + "]";
	}

	public static void main(String[] args) {
		FinalVariable f=new FinalVariable(105);
		System.out.println(f);
		
	}
	
	

}


