package abstract1;

public class PermanentEmployee extends Employee {
	  private double basicPay;

	  public PermanentEmployee(int employeeId, String employeeName, double basicPay) {
	        super(employeeId, employeeName);
	        this.basicPay = basicPay;
	    }

	
	
	 @Override
	    public void caluclateSalary() {
	        salary = basicPay - (0.12 * basicPay);  // Deducting 12% tax
	    }



	
	}
	


