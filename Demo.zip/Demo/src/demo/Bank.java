package demo;

import basics.*;

public class Bank {


public static void main(String[] args) {
	Customer1 c=new Customer1(1, "vivek", 290.4);
	c.diplay();
	
}
}
