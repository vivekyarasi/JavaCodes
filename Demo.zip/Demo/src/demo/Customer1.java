package demo;

public class Customer1 {
	int id;
	String name;
	Double amt;
	public Customer1(
			
			
			
			int id, String name, Double amt) {
		
		this.id = id;
		this.name = name;
		this.amt = amt;
	}
	public void diplay(){
		System.out.println("id = "+id+" name = "+name+"amount = "+amt);
		
	}
	public static void main(String[] args) {
		Customer1 c=new Customer1(1,"chinna",1123.56d);
		c.diplay();
	}

}
