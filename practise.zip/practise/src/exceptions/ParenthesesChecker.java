package exceptions;

import java.util.Scanner;
import java.util.Stack;

public class ParenthesesChecker {
    public static String isBalanced(String str) {
        if (!str.matches("[{}()\\\\[\\\\]]*")) {
            return "Invalid input. Only parentheses are allowed";
        }
        
        if (str.isEmpty()) {
            return "Balanced";
        }
        
        Stack<Character> stack = new Stack<>();
        for (char ch : str.toCharArray()) {
            if (ch == '{' || ch == '(' || ch == '[') {
                stack.push(ch);
            } else {
                if (stack.isEmpty()) {
                    return "Unbalanced";
                }
                char top = stack.pop();
                if ((ch == '}' && top != '{') ||
                    (ch == ')' && top != '(') ||
                    (ch == ']' && top != '[')) {
                    return "Unbalanced";
                }
            }
        }
        
        return stack.isEmpty() ? "Balanced" : "Unbalanced";
    }
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a string with parentheses: ");
        String input = scanner.nextLine();
        System.out.println(isBalanced(input));
        scanner.close();
    }
}

