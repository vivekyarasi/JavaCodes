package exceptions;

import java.util.Scanner;

public class UnChecked extends Exception {
	
	public static void checkInt(int number)throws IllegalArgumentException,ArithmeticException {
		if(number < 0) {
			throw new IllegalArgumentException("negative number is not valid");
		}else if(number == 0) {
			throw new ArithmeticException("Zero number is not valid");
		}else {
			System.out.println("Valid Number:"+number);
		}
		
	}
	public static void checkString(String name)throws IllegalArgumentException,RuntimeException{
		if(name.length()==0) {
			throw new IllegalArgumentException("string is not valid");
		}else if(name.length() < 5) {
			throw new RuntimeException("string less than 5") ;
			}else {
				System.out.println("valid Name:"+name);
			}
			
		}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a Number:");
		try {
			int num=sc.nextInt();
			checkInt(num);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		System.out.println("Enter a String:");
		Scanner scanner=new Scanner(System.in);
		try {
			String text=scanner.next();
			checkString(text);
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			System.out.println("Finally Block executed");
			sc.close();
			scanner.close();
		}
			}
	

}
