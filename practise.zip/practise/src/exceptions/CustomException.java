package exceptions;

import java.util.Scanner;

class AgeException extends Exception{
	public AgeException(String msg) {
		super(msg);
	}
}
public class CustomException {
	public static void checkAge(int age)throws AgeException {
		if(age<18) {
			throw new AgeException("Your age is below 18");
		}else {
			System.out.println("You are eligibile for vote");
		}
		
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your age");
		try {
			int num=sc.nextInt();
			checkAge(num);
		} catch (AgeException e) {
			System.out.println(e.getMessage());;
			
		}finally {
			sc.close();
		}
		
	}
	

}
