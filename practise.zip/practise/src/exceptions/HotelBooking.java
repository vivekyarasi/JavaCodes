package exceptions;

import java.util.Scanner;

class RoomTypeNotAvailableException extends Exception{
	public RoomTypeNotAvailableException(String message) {
		super(message);
	}
}

class InvalidStayDurationException extends Exception{
	public InvalidStayDurationException(String message) {
		super(message);
	}
	
}
class InsufficientBalanceException extends Exception{
	public InsufficientBalanceException(String message) {
		super(message);
	}
}
public class HotelBooking {
	private double balance;
	private static final double ROOM_COST = 100.0;
	private static final String[] AVAILABLE_ROOMS = {"Single", "Double", "Suite"};

	public HotelBooking(double balance) {
		
		this.balance = balance;
	}
	
	public boolean isRoomTypeAvailable(String roomtype) {
		for(String room:AVAILABLE_ROOMS) {
			if(room.equalsIgnoreCase(roomtype)) {
				return true;
			}
		}
		return false;
		
	}
	public double getBalance(double balance) {
		return balance;
	}
	public void bookRoom(String roomType, double payment, int days) throws RoomTypeNotAvailableException,InvalidStayDurationException,InsufficientBalanceException {
		if(!isRoomTypeAvailable(roomType)) {
			throw new RoomTypeNotAvailableException("RoomType "+roomType+"is not available");
			
		}if (days <= 0) {
			throw new InvalidStayDurationException("Stay duration must be positive. Invalid stay: " + days);
		}
		double totalCost = ROOM_COST * days;
		if (payment < totalCost) {
		throw new InsufficientBalanceException("Payment of " + payment + " is insufficient. Total cost is " + totalCost);
		}
		balance -= payment;
		System.out.println("Room booked successfully! Remaining balance: Rs " + balance);
		}
		
		
		public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		double balance = sc.nextDouble();
		HotelBooking booking = new HotelBooking(balance);
		String roomType = sc.next();
		double payment = sc.nextDouble();
		int days = sc.nextInt();
		try {
		booking.bookRoom(roomType, payment, days);
		} catch (RoomTypeNotAvailableException | InsufficientBalanceException | InvalidStayDurationException e) {
			System.out.println(e.getMessage());
		}
		sc.close();
	}
		}


