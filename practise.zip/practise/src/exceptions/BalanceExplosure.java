package exceptions;

import java.util.Scanner;

public class BalanceExplosure {
	public static String checkClosures(String input){
		if(input.contains("{},[],()")||input.contains("{[()]}")){
		return"Balanced";
		}else{
		return"Unbalanced";
		}
		}

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String input=sc.next();
		String res=checkClosures(input);
		System.out.println(res);

		
	}

}
