package com.java.postgrassql;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class Demo1 {
    public static void main(String[] args) {
        try {
           

            Connection con = DbConnection.getConnection();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM employees ");
//       int rowsupdated=  st.executeUpdate("update  employees set name='shiva' where id in(1,2)");
//       System.out.println(rowsupdated);
//       if (rowsupdated>0){
//    	   System.out.println("updated succesffuly"+"rows affected"+":"+rowsupdated);
//    	   
//       }
//       else {
//    	   System.out.println("No rows affected");
//       }
            
       while (rs.next()) {
                System.out.println(rs.getString(1) + " " + rs.getString(2)+" "+rs.getString(3) );
           }

          rs.close();
            st.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
