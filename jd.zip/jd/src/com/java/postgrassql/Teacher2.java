package com.java.postgrassql;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class Teacher2 {
	public static void main(String[] args) {
		try{
			Connection con=DbConnection.getConnection();
			
			Scanner sc=new Scanner(System.in);
			int i=sc.nextInt();
			
			PreparedStatement st=con.prepareStatement("select * from teachers where id=?");
			st.setInt(1, i);
			ResultSet set=st.executeQuery();
			
			while(set.next()) {
				System.out.println(set.getInt(1)+" "+set.getString(2)+" "+set.getString(3)+" "+set.getString(4));
			}
		}
		catch(Exception e) {
			System.out.println(e);
			
		}
	}

}
