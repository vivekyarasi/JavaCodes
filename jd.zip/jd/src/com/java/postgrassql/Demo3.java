package com.java.postgrassql;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class Demo3 {
	public static void main(String[] args) {
		try {
			
	Connection con=	DbConnection.getConnection();	
		
//Statement st=con.createStatement();
Scanner s=new Scanner(System.in);
int d=s.nextInt();
String s2=s.next();
double sal=s.nextDouble();
String sql="insert into employees values(?,?,?)";
PreparedStatement ps=con.prepareStatement(sql);
ps.setInt(1, d);
ps.setString(2,s2);
ps.setDouble(3, sal);
int d1=ps.executeUpdate();
if(d1>0)
{
	System.out.println("1 row inserted");
}

	}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
