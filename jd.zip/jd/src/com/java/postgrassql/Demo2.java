package com.java.postgrassql;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class Demo2 {
	public static void main(String[] args) {
		try {
			
	Connection con=	DbConnection.getConnection();	
		
//Statement st=con.createStatement();
Scanner s=new Scanner(System.in);
int d=s.nextInt();;
PreparedStatement ps=con.prepareStatement("select * from employees where id=?");
ps.setInt(1, d);
ResultSet rs=ps.executeQuery();
while(rs.next())
{
	System.out.println(rs.getInt(1)+" "+rs.getString(2));
}

	}
		catch(Exception e)
		{
			System.out.println(e);
		}

}
}



