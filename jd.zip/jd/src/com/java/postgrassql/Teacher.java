package com.java.postgrassql;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class Teacher {
	public static void main(String[] args) {
		try {
			
			Connection con=DbConnection.getConnection();
			Statement st=con.createStatement();
			ResultSet result=st.executeQuery("select * from teachers");
			
			while(result.next()) {
				System.out.println(result.getInt(1)+" "+result.getString(2)+" "+result.getString(3)+" "+result.getInt(4));
			}
			result.close();
			st.close();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	

}
