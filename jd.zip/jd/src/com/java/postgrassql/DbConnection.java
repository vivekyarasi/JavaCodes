package com.java.postgrassql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbConnection {
    public static Connection getConnection() throws SQLException {
        System.out.println("Attempting to connect to the database...");

        Connection con = DriverManager.getConnection(
                "jdbc:postgresql://localhost:5432/sundaram",
                "postgres",
                "sundaram123"
        );

        System.out.println("Database connection successful!");
        return con;
    }
}