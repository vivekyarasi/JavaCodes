package jdcom.dao.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;



public class DbConnection {
	public static void main(String[] args) {
		Connection con=null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
		con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","SYSTEM","1804");
		Statement st=con.createStatement();
		ResultSet rs=st.executeQuery("select * from hr.locations");
		while(rs.next())
		{
			System.out.println(rs.getInt(1)+" "+rs.getString(2));
		}

			
				
		}
			catch(Exception e)
			{
				System.out.println(e);
			}
	}

}
