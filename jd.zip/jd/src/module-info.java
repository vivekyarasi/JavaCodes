/**
 * 
 */
/**
 * 
 */
module jd {
	requires java.sql;
}